import SpriteKit

open class LoveWorld: World {
	
	///The normal state before infection.
	override open func normalState(_ h: Human.Entity) -> (Human.Kind, SKAction?) {
		return (.Smile1, nil)
	}
	
	//The state after infection.
	override open func infectedState(_ h: Human.Entity) -> (Human.Kind, SKAction?) {
		
		//Start rotating
		let action1 = SKAction.rotate(byAngle: 2.1 * CGFloat.pi,
		                              duration: 1)
		
		//Spawn hearts
		let action2 = SKAction.run { [weak self] in
			
			//Create a Heart item
			let h = self?.createItem(withKind: .Love,
			                         inPosition: h.humanVisual.skNode.position)
			
			//Fade out
			let fade = SKAction.fadeOut(withDuration: 1)
			//Dispose
			let nodeRemove = SKAction.removeFromParent()
			let entityRemove = SKAction.customAction(withDuration: 0.1,
			                                         actionBlock: { [weak self] (node, duration) in
				guard
					let entity = node.entity,
					let item = entity as? Item.Entity
					else { return }
				
				self?.gkScene.removeEntity(item)
			})
			
			//Compose actions in a sequence
			let sequence = SKAction.sequence([
				fade, nodeRemove, entityRemove
				])
			
			//And run! 🏁
			h?.itemVisual.skNode.run(sequence)
		}
		
		//Compose actions in a sequence
		let sequence = SKAction.sequence([
			action1,
			action2
			])
		
		//Return as (nextKind, human action?)
		return (.InLove, SKAction.repeatForever(sequence))
	}
}
