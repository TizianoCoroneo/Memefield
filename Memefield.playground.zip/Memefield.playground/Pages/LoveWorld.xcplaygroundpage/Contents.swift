//: [Previous](@previous)

import SpriteKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

let (view, scene) = Create.world(LoveWorld.self)
defer { PlaygroundPage.current.liveView = view }

/*:

---
---

In this page, we'll try to fight the fake news problem with the most powerful weapon: love.

---
---

*Try to infect someone with love*

---
---

Isn't a world like this better?

---
---

As before, you can change population and background:
*/
scene.population = [
	Human.Kind.Angriest : 20,
	Human.Kind.Angry: 15,
	Human.Kind.Insult: 20
]

scene.backgroundNode = SKSpriteNode(imageNamed: "Background/Grass")
//: And this time you can change also the probability of infection: in this case 0.8 means 80% of probability per each contact that the user will get infected.
scene.infectivity = 0.8
//: You can also change the next parameter to false to deactivate immunity from the infection.
scene.allowImmunity = false
/*: 

---

Now do some stretching: you're going to play soccer.

[Next](@next)

- [Intro](Intro)
- [FakeWorld](FakeWorld)

- [SoccerWorld](SoccerWorld)
- [Sandbox](Sandbox)


*/
