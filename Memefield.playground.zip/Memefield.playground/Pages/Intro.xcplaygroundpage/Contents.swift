/*: [Previous](@previous)

- Callout(Remember):
	Please activate the rendered markup documention from the right menu or from the Editor menu, if you're using this in XCode.

- Callout(Remember):
	Always do what's good for humanity.

---
---
---

## Welcome to
# Memefield
# 💬🕸
### by Tiziano Coroneo

---

Observe the **users** of a **chat app** as **fake stories/news** spread around.

Understand **infection dynamics** to defeat **misinformation**!

---
---
---

The main experience is the first world ("FakeWorld"), where you'll observe the fake news phenomenon. 

You'll find two simpler (and waaay funnier) scenes too: "LoveWorld", where we treat angry people with love, and "SoccerWorld", which actually could have been called "Little children play soccer simulator".

You'll also find another scene: "Sandbox". Here you can customize your scenes directly from the playground page, without messing around in Sources ;)
Every scene is based on the same code. You can create new scenes by subclassing `World`.

You'll find instructions on what to do here in the main editor, and you should also open the Assisant Editor (⌘⌥↩︎) in "Timeline" mode.
*/
import SpriteKit
let whatTheAssistantEditorModeSelectorShouldLookLike = #imageLiteral(resourceName: "Timeline.png")
/*:

---
---

## Index

- [FakeWorld](FakeWorld)
- [LoveWorld](LoveWorld)
- [SoccerWorld](SoccerWorld)
- [Sandbox](Sandbox)

[Next](@next)
*/
