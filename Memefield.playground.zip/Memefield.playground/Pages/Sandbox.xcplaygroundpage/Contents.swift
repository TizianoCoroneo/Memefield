//: [Previous](@previous)

import SpriteKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

let (view, scene) = Create.world(SandboxWorld.self)
defer { PlaygroundPage.current.liveView = view }
/*:

---
---

In this page, you can do whatever you want.
You have the usual parameters: 
*/
scene.population = [
	Human.Kind.ZombieMale : 8,
	Human.Kind.ZombieFemale : 8,
	Human.Kind.SoldierMale : 8,
	Human.Kind.SoldierFemale : 8
]

scene.backgroundNode = SKSpriteNode(imageNamed: "Background/Gray")

scene.infectivity = 1
scene.allowImmunity = true
/*:
And I have also exposed the state functions that regulate what users do:

- At the beginning: normalState
- When clicked/tapped: firstInfectedState
- When infected by another user: infectedState
- When immune: immuneState
*/
scene.normalStateClosure = { entity in
	return (.Angel, nil)
}

scene.infectedStateClosure = { entity in
	return (.Skull, SKAction.repeatForever(SKAction.rotate(byAngle: CGFloat.pi, duration: 0.3)))
}

scene.firstInfectedStateClosure = { entity in
	return (.Devil, SKAction.repeatForever(SKAction.rotate(byAngle: 2 * CGFloat.pi, duration: 0.3)))
}

scene.immuneStateClosure = { entity in
	return (.Sleeping, nil)
}
//: There's also this closure, which will get called on contact between physics bodies.
let contactForce: CGFloat = 50
scene.contactEvent = { contact in
	guard let (a, b) = scene.contactToEntities(contact) else { return }
//: Here on the right part you can see the total number of collisions in the scene.
	let vector = CGVector(dx: CGFloat(scene.randomSource.nextUniform() - 0.5) * contactForce, dy: CGFloat(scene.randomSource.nextUniform() - 0.5) * contactForce)
	
	a.humanVisual.skNode.physicsBody?.applyImpulse(vector)
	
	return
}
/*:
---
---

# HAVE FUN

---
---

Or go back.

- [Intro](Intro)
- [FakeWorld](FakeWorld)
- [LoveWorld](LoveWorld)
- [SoccerWorld](SoccerWorld)

*/
