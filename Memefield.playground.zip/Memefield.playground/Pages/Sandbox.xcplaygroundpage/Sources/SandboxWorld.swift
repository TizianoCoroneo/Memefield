import SpriteKit
import GameplayKit

open class SandboxWorld: World {
	
	//Closure that will be executed upon contact between physic bodies.
	open var contactEvent: ((SKPhysicsContact) -> ())? = nil
	
	//Inject the contactEvent into the contactDelegate
	open override func didBegin(_ contact: SKPhysicsContact) {
		super.didBegin(contact)
		
		self.contactEvent?(contact)
	}
}
