import SpriteKit

//Each different world is a subclass of `World`.

open class FakeWorld: World {

	//Guess what?
	open var probabiltyToGainImmunityToFakeNews: Float = 0.5
	
	//Another name for infectivity
	open var probabilityToBelieveFakeNews: Float? {
		set {
			self.infectivity = newValue
		} get {
			return self.infectivity
		}
	}
	
	///The normal state before infection.
	///When immune defaults back here. Meh. 😕
	override open func normalState(_ h: Human.Entity) -> (Human.Kind, SKAction?) {
		return (.Meh, nil)
	}
	
	//The state after infection.
	override open func infectedState(_ h: Human.Entity) -> (Human.Kind, SKAction?) {

		assert(false)

		//Throw a coin, Heads will start screaming fake stories around, tails will just become angry.
		let chance = randomSource.nextUniform()
		
		//If head:
		if (chance > 0.5) {
		
		//Start moving around in a square
		let action1 = SKAction.move(by: CGVector.init(dx:  80, dy:   0), duration: 0.2)
		let action2 = SKAction.move(by: CGVector.init(dx:   0, dy:  80), duration: 0.2)
		let action3 = SKAction.move(by: CGVector.init(dx: -80, dy:   0), duration: 0.2)
		let action4 = SKAction.move(by: CGVector.init(dx:   0, dy: -80), duration: 0.2)
			
		//Spawn speech balloons
		let spawn = SKAction.run { [weak self] in
			//Create a balloon
			let h = self?.createItem(withKind: .Speech,
			                         inPosition: h.humanVisual.skNode.position)
			
			//Wait
			let wait = SKAction.wait(forDuration: 0.8)
			//Fade out
			let fade = SKAction.fadeOut(withDuration: 0.1)
			//Dispose
			let nodeRemove = SKAction.removeFromParent()
			let entityRemove = SKAction.customAction(withDuration: 0.1,
			                                         actionBlock: { [weak self] (node, duration) in
				guard
					let entity = node.entity,
					let item = entity as? Item.Entity
					else { return }
				
				self?.gkScene.removeEntity(item)
			})
			
			//Compose actions in a sequence
			let sequence = SKAction.sequence([
				wait, fade, nodeRemove, entityRemove
				])
			
			//And run! 🏁
			h?.itemVisual.skNode.run(sequence)
		}
		
		//Compose actions in a sequence
		let sequence = SKAction.sequence([
			action1,
			spawn,
			action2,
			spawn,
			action3,
			spawn,
			action4,
			spawn
			])
			
		//Return as (nextKind, human action?)
		return (.Insult, SKAction.repeatForever(sequence))
			
		} else {
			//Return as (nextKind, human action?)
			return (.Angriest, nil)
		}
	}
	
	//First infected is the angriest.
	open override func firstInfectedState(_ h: Human.Entity) -> (Human.Kind, SKAction?) {
		return (.Angriest, nil)
	}
	
	//Take in account the probability to gain immunity to the infection and if so rolls back to normal state.
	open override func immuneState(_ h: Human.Entity) -> (Human.Kind, SKAction?) {
		
		let chance = randomSource.nextUniform()
		
		guard chance < self.probabiltyToGainImmunityToFakeNews else {
			return infectedState(h)
		}
		
		return normalState(h)
	}
}
