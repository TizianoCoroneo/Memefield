//: [Previous](@previous)

import SpriteKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

let (view, scene) = Create.world(FakeWorld.self)
defer { PlaygroundPage.current.liveView = view }

/*:

---
---

All modern societies are fighting against a very difficult problem: the spreading of fake news and the quest for truth.

# 🤔

In this page, the playground live view simulates the population of a chat app. Each user is represented with a different emoji: 

# 😎😒☺️

If you try to click one of the users, he will become angry 😡 and will start spreading fake stories 💬 around.
Whenever he touches someone, it will spread the story like a virus.

(There will be also some of the new Unicode 10.0 emoji which I can't use in text yet 😅)

---
---

*Try to click one of the users.*

---
---

After a little while, every one is running around telling fake stuff to everyone. No one is spared. 

# 😡💬😡💬😡

The problem is that angry people are engaged people. Fake news make people upset: upset people talk a lot. 

## Angry == Engaged

They send messages to every contact, without checking if they are true first. And this just make people angry or worried for nothing.

	"Hey, look out for this‼️ Dangerous‼️1‼️"

People become angry for reasons that simply don't exist.

If someone proves that the story everyone is speaking about is false, people should calm down.

---
---

*Try to calm down an angry user.*

---
---

Explaining reasons of why a certain thing is false to someone can be really difficult. People like to be right, and people like to feel secure, so just telling them they're wrong won't sort any effect.

I've represented the probability to gain "Fake news immunity" with a static variable with a very long unoriginal name:
*/
scene.probabiltyToGainImmunityToFakeNews = 0.5
/*:
- Probability = 1 ➡️ User will always accept the explanation and become immune to fake news 🙌.
- Probability = 0.5 ➡️ There a 50% chance that the user will just continue to spread fakes ☹️.

There's also another variable for the probability to believe fake news once exposed to them.
*/
scene.probabilityToBelieveFakeNews = 0.9
/*:

---
---

*Change both probabilities to 1 and see what happens*

---
---

The average newly-immunized user will just feel like:

	"Huh. You're right. Sorry 😕"

And then will go back to normal.

You'll almost surely notice some angry users left in our little world. Nobody reached out to them to tell them: 

	"Hey. I'm sorry, that's fake"

# 🤦‍♂️🤦‍♀️

This is the problem we're facing.

People engage with fake stories more than with the true versions of them.

This is my little visualization of this problem.

In reality I think people find it easier to identify a single enemy instead of understanding the real causes of their problems.

I think that a responsible society should focus on helping anyone to achieve serenity. 

People who don't have to worry about how to survive the next day don't look out for enemies.

Hope you enjoyed this playground. 😊

If you want to play more with the simulation system, there are two more scenes with different themes, and the last page is a free sandbox-like environment that you can configure as you like, just like these:
*/
//In the `population` dictionary the key represent the kind of human which will appear in the view, and the value is how many of them you wish to create.
scene.population = [
	Human.Kind.Annoyance	: 12,
	Human.Kind.Cute			: 15,
	Human.Kind.Cool			: 10
]

//This is the background node instead 🏞
scene.backgroundNode = SKSpriteNode(imageNamed: "Background/Chat")
/*: 

---

From here you can go to the bonus scenes or to the sandbox.

- [Intro](Intro)

- [LoveWorld](LoveWorld)
- [SoccerWorld](SoccerWorld)
- [Sandbox](Sandbox)

*/
