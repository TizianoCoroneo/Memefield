//: [Previous](@previous)

import SpriteKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

let (view, scene) = Create.world(SoccerWorld.self)
defer { PlaygroundPage.current.liveView = view }

/*:

---
---

In this page, you'll see the **least accurate** soccer simulation ever made.

It doesn't even work as I expected, but I've found the result quite funny, so I've included it anyway 😂

When you infect someone, a ball will appear and the infected emoji will start seeking it.

When a infected emoji reaches the ball, it kicks it in a random direction, with a random impulse. Of course.

It is basically a "Children play soccer" simulator.

---
---

*Try to give to someone a soccer ball*

---
---

I've never really played soccer. What a shame.

---
---

As before, you can change some parameters.

*/
scene.population = [
	Human.Kind.Annoyance : 50
]

scene.backgroundNode = SKSpriteNode(imageNamed: "Background/Grass")

scene.infectivity = 1
scene.allowImmunity = false
/*: 

---

The sandbox... pay attention to the zombies. They bite.

[Next](@next)

- [Intro](Intro)
- [FakeWorld](FakeWorld)
- [LoveWorld](LoveWorld)

- [Sandbox](Sandbox)

*/









