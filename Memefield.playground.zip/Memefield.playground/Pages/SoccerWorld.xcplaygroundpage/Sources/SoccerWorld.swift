import SpriteKit
import GameplayKit

open class SoccerWorld: World {
	
	//TODO: I really have to rewrite this awful stuff.
	// I don't even bother documenting this code. It's simply a joke.
	
	var ball: HumanSpriteNode? {
		return self.childNode(withName: SoccerWorld.ballName) as? HumanSpriteNode
	}
	
	var ballEntity: Item.Entity? {
		return ball?.entity as? Item.Entity
	}
	
	var ballCreated: Bool = false
	
	static let ballName = "Ball"
	static let kickDistance: CGFloat = 44
	
	override open func normalState(_ h: Human.Entity) -> (Human.Kind, SKAction?) {
		return (.Smile1, nil)
	}
	
	override open func infectedState(_ h: Human.Entity) -> (Human.Kind, SKAction?) {
		
		let spawn = SKAction.run { [weak self] in
			guard !(self!.ballCreated) else { return }
			self?.ballCreated = true
			
			let item = self?.createItem(withKind: .Ball,
			                            inPosition: h.humanVisual.skNode.position)
			
			item?.itemVisual.skNode.physicsBody?.mass = 0
			item?.itemVisual.skNode.physicsBody?.friction = 0
			item?.itemVisual.skNode.physicsBody?.restitution = 1
			
			item?.itemVisual.skNode.name = SoccerWorld.ballName
		}
		
		let follow = SKAction.run {
			
			guard let bAgent = self.ballEntity?.itemAgent else { return }
			
			let goal = GKGoal(toSeekAgent: bAgent)
			let behavior = GKBehavior(goal: goal, weight: Humanity.defaultBehaviourWeight)
			
			h.humanAgent.behavior = behavior
		}
		
		let sequence = SKAction.sequence([
			spawn,
			follow
			])
		
		h.humanAgent.maxSpeed = 400
		h.humanAgent.mass = 5
		h.humanAgent.maxAcceleration = 400
		
		return (.Smile2, sequence)
	}
	
	open override func didBegin(_ contact: SKPhysicsContact) {
		super.didBegin(contact)
		
		guard
			let nameA = contact.bodyA.node?.name,
			let nameB = contact.bodyB.node?.name,
			nameA == "Ball" || nameB == "Ball"
			else { return }
		
		let vector = CGVector(dx: CGFloat(arc4random_uniform(300)) - 150,
		                      dy: CGFloat(arc4random_uniform(300)) - 150)
		
		ballEntity?.itemVisual.skNode.physicsBody?.applyImpulse(vector)
	}
}
