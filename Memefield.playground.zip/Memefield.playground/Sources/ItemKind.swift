import SpriteKit
import GameplayKit

extension Item {
	
	///All the possible items.
	public enum Kind: String {
		
		//TODO: Find a way to read these directly from the emoji font, getting their Unicode name as rawValue.
		
		case Love = "Love"					//❤️
		case Speech = "Speech"				//💬
		case AngrySpeech = "AngrySpeech"	//🗯
		case Thought = "Thought"			//💭
		case Ball = "Ball"					//⚽️
		

		//All the enum cases.
		public static func allCases() -> [Kind] {
			return [
				.Love,
				.Speech,
				.AngrySpeech,
				.Thought,
				.Ball
			]
		}
		
		// A random enum case.
		public static func random() -> Kind {
			let cases = allCases()
			let rand = Int(arc4random_uniform(UInt32(cases.count)))
			return cases[rand]
		}
		
		//This case corresponding `SKTexture`.
		public func texture() -> SKTexture {
			return SKTexture(imageNamed: self.rawValue)
		}
	}
}
