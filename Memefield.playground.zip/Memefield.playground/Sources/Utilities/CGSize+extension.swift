import CoreGraphics

//CGSize, CGFloat and CGVector operations.
extension CGSize {
	
	public static func +(lhs: CGSize, rhs: CGSize)	-> CGSize { return CGSize(width: lhs.width + rhs.width, height: lhs.height + rhs.height) }
	public static func -(lhs: CGSize, rhs: CGSize)	-> CGSize { return CGSize(width: lhs.width - rhs.width, height: lhs.height - rhs.height) }
	public static func *(lhs: CGFloat, rhs: CGSize) -> CGSize { return CGSize(width: lhs*rhs.width, height: lhs*rhs.height) }
	public static func *(lhs: Int, rhs: CGSize)		-> CGSize { return CGFloat(lhs)*rhs }
	public static func *(lhs: Double, rhs: CGSize)	-> CGSize { return CGFloat(lhs)*rhs }
	public static func /(lhs: CGSize, rhs: CGFloat) -> CGSize { return CGSize(width: lhs.width/rhs, height: lhs.height/rhs) }
	public static func /(lhs: CGSize, rhs: Int)		-> CGSize { return lhs/CGFloat(rhs) }
	public static func /(lhs: CGSize, rhs: Double)	-> CGSize { return lhs/CGFloat(rhs) }
	public init(with vector: CGVector) { (self.width, self.height) = (vector.dx, vector.dy) }
	public init(squareOf side: CGFloat) { self.init(width: side, height: side) }
	public var cgVector: CGVector { return CGVector(dx: self.width, dy: self.height) }
	public func cgRect(centeredIn point: CGPoint) -> CGRect { return CGRect(origin: point - (self/2).cgVector, size: self) }
	public var cgRect: CGRect { return cgRect(centeredIn: CGPoint.zero) }
}
