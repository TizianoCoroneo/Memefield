import CoreGraphics

//CGRect randomPoint and center.
extension CGRect {
	
	public var randomPoint: CGPoint {
		let w = Int(arc4random_uniform(UInt32(self.width)))
		let h = Int(arc4random_uniform(UInt32(self.height)))
		return CGPoint(x: w, y: h)
	}

	public var center: CGPoint {
		get { return CGPoint(
			x: self.origin.x + self.size.width*CGFloat(0.5),
			y: self.origin.y + self.size.height*CGFloat(0.5)
			)
		}
		set {
			self.origin = CGPoint(
				x: newValue.x - self.size.width*CGFloat(0.5),
				y: newValue.y - self.size.height*CGFloat(0.5)
			)
		}
	}

}

