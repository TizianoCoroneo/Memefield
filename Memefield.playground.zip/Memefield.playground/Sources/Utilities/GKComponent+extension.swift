import GameplayKit
import SpriteKit

//Various connections between components, entities and the scene.
extension GKComponent {
	
	public var human: Human.Entity? {
		guard
			let entity = entity,
			let human = entity as? Human.Entity
			else { return nil }
		
		return human
	}
	
	public var world: World? {
		guard let human = human else { return nil }
		return human.scene
	}
	
	public var kind: Human.Kind? {
		return human?.kind
	}

	public var item: Item.Entity? {
		guard
			let entity = entity,
			let item = entity as? Item.Entity
			else { return nil }
		
		return item
	}

}
