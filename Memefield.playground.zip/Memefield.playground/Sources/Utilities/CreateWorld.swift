import SpriteKit

//Utility class to create worlds in the playground pages with a nice syntax.
open class Create {
	
	static open func world<T>(_ type: T.Type, withFrame frame: CGRect? = nil) -> (view: SKView, scene: T) where T: World {
		
		let f = frame ?? CGRect(x: 0, y: 0, width: 400, height: 700)
		
		let scene = T.init(size: f.size)
		let view = SKView.init(frame: f)
		
		view.presentScene(scene)
		
		return (view: view, scene: scene)
	}
}
