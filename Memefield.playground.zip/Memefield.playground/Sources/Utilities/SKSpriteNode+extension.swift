import SpriteKit

extension SKSpriteNode {
	
	//Sprite proportional fill method.
	func fillTo(size: CGSize) {
		
		guard let t = texture else { return }
		
		self.size = t.size()
		
		let verticalRatio = size.height / self.size.height
		let horizontalRatio = size.width /  self.size.width
		
		let ratio = horizontalRatio > verticalRatio ? horizontalRatio : verticalRatio
		
		self.setScale(ratio)
	}
}
