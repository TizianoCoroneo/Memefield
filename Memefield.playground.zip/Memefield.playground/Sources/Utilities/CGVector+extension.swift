import CoreGraphics

//CGVector, CGFloat operations.
extension CGVector {

	public static func +(lhs: CGVector, rhs: CGVector)	-> CGVector { return CGVector(dx: lhs.dx + rhs.dx, dy: lhs.dy + rhs.dy) }
	public static func -(lhs: CGVector, rhs: CGVector)	-> CGVector { return CGVector(dx: lhs.dx - rhs.dx, dy: lhs.dy - rhs.dy) }
	public static func *(lhs: CGVector, rhs: CGVector)	-> CGFloat  { return CGFloat(lhs.dx*rhs.dx + lhs.dy*rhs.dy) }
	public static func *(lhs: CGFloat, rhs: CGVector)	-> CGVector { return CGVector(dx: lhs*rhs.dx, dy: lhs*rhs.dy) }
	public static func *(lhs: Int, rhs: CGVector)		-> CGVector { return CGFloat(lhs)*rhs }
	public static func *(lhs: Double, rhs: CGVector)	-> CGVector { return CGFloat(lhs)*rhs }
	public static func /(lhs: CGVector, rhs: CGFloat)	-> CGVector { return CGVector(dx: lhs.dx/rhs, dy: lhs.dy/rhs) }
	public static func /(lhs: CGVector, rhs: Int)		-> CGVector { return lhs/CGFloat(rhs) }
	public static func /(lhs: CGVector, rhs: Double)	-> CGVector { return lhs/CGFloat(rhs) }
	public var squaredNorm: CGFloat { return self * self }
	public var norm: CGFloat { return sqrt(self.squaredNorm) }
	public func cgPoint(from point: CGPoint) -> CGPoint { return CGPoint(x: point.x + self.dx, y: point.y + self.dy) }
	public var cgPoint: CGPoint { return self.cgPoint(from: CGPoint.zero) }
	public static func unit(with angle: CGFloat = 0) -> CGVector { return CGVector(dx: cos(angle), dy: sin(angle)) }
}
