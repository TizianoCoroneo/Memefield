import CoreGraphics

//CGPoint and CGVector operations.
extension CGPoint {
	
	public static func +(lhs: CGPoint, rhs: CGVector) -> CGPoint { return CGPoint(x: lhs.x + rhs.dx, y: lhs.y + rhs.dy) }
	
	public static func -(lhs: CGPoint, rhs: CGVector) -> CGPoint { return CGPoint(x: lhs.x - rhs.dx, y: lhs.y - rhs.dy) }
	
	public static func -(lhs: CGPoint, rhs: CGPoint) -> CGVector { return CGVector(dx: rhs.x - lhs.x, dy: rhs.y - lhs.y) }
	
	public func distance(from point: CGPoint) -> CGFloat { return (point - self).norm }
	
	public var cgVector: CGVector { return CGVector(dx: self.x, dy: self.y) }
}
