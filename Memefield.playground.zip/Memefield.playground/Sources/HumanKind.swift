import SpriteKit
import GameplayKit

///Protocol needed to observe changes to the `Human.Entity.kind`.
public protocol HumanKindWatcher {
	func update(kind: Human.Kind)
}

extension Human {
	
	///All the possible humans! Yeeee!
	public enum Kind: String {
		
		//TODO: Greatly increse this list 😏
		//TODO: Find a way to read these directly from the emoji font, getting their Unicode name as rawValue.
		case Angel			= "Angel"			//😇
		case Angriest		= "Angriest"		//😠
		case Angry			= "Angry"			//😡
		case Annoyance		= "Annoyance"		//😒
		case BadWords		= "BadWords"		//Unicode 10.0
		case Clown			= "Clown"			//🤡
		case Cool			= "Cool"			//😎
		case Cry			= "Cry"				//😭
		case Cute			= "Cute"			//😊
		case Devil			= "Devil"			//😈
		case Disappointed	= "Disappointed"	//🙁
		case Distraught		= "Distraught"		//😫
		case FacepalmMale	= "FacepalmMale"	//🤦‍♂️
		case FacepalmFemale	= "FacepalmFemale"	//🤦‍♀️
		case Hey			= "Hey"				//😏
		case Indiana		= "Indiana"			//🤠
		case InLove			= "InLove"			//😍
		case Insult			= "Insult"			//Unicode 10.0
		case Kiss			= "Kiss"			//😘
		case Laugh			= "Laugh"			//😆
		case LaughCry		= "LaughCry"		//😂
		case LaughRoll		= "LaughRoll"		//🤣
		case Meh			= "Meh"				//😕
		case MoneyFace		= "MoneyFace"		//🤑
		case Nerd			= "Nerd"			//🤓
		case NoMouth		= "NoMouth"			//😶
		case OhMyGod		= "OhMyGod"			//😱
		case Robot			= "Robot"			//🤖
		case Sad			= "Sad"				//😞
		case Sick1			= "Sick1"			//😷
		case Sick2			= "Sick2"			//Unicode 10.0
		case Skull			= "Skull"			//💀
		case Sleeping		= "Sleeping"		//😴
		case Smile1			= "Smile1"			//😀
		case Smile2			= "Smile2"			//😃
		case SoldierMale	= "SoldierMale"		//💂
		case SoldierFemale	= "SoldierFemale"	//💂‍♀️
		case StarEyes		= "StarEyes"		//Unicode 10.0
		case VerySick		= "VerySick"		//🤢
		case ZombieFemale	= "ZombieFemale"	//Unicode 10.0
		case ZombieMale		= "ZombieMale"		//Unicode 10.0
		
		//All the enum cases.
		public static func allCases() -> [Kind] {
			return [
			.Angel,
			.Angriest,
			.Angry,
			.Annoyance,
			.BadWords,
			.Clown,
			.Cool,
			.Cry,
			.Cute,
			.Devil,
			.Disappointed,
			.Distraught,
			.FacepalmMale,
			.FacepalmFemale,
			.Hey,
			.Indiana,
			.InLove,
			.Insult,
			.Kiss,
			.Laugh,
			.LaughCry,
			.LaughRoll,
			.Meh,
			.MoneyFace,
			.Nerd,
			.NoMouth,
			.OhMyGod,
			.Robot,
			.Sad,
			.Sick1,
			.Sick2,
			.Skull,
			.Sleeping,
			.Smile1,
			.Smile2,
			.SoldierMale,
			.SoldierFemale,
			.StarEyes,
			.VerySick,
			.ZombieFemale,
			.ZombieMale
			]
		}
		
		// A random enum case.
		public static func random() -> Kind {
			let cases = allCases()
			let rand = Int(arc4random_uniform(UInt32(cases.count)))
			return cases[rand]
		}
		
		//This case corresponding `SKTexture`.
		public func texture() -> SKTexture {
			
			return SKTexture(imageNamed: self.rawValue)
		}
	}
}
