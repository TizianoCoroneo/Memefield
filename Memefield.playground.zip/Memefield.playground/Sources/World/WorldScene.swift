import SpriteKit
import GameplayKit

/// Main `SKScene` subclass. Defines basic properties of all the playground worlds.
open class World: SKScene, InfectableWorld {
	
	//TODO: This class is a mess. I apologize. It REALLY REALLY needs a reformat.
	
	///How far way the physics body frame is from the scene.frame
	open static let physicFrameInset: CGFloat = -50.0
	
	///Does this world allows immune humans?
	open var allowImmunity: Bool = true
	
	///When set, remove all the human spritenodes and recreate them with the new population.
	open var population: [Human.Kind: Int] = [:] {
		didSet {
			
			//Find human nodes
			let childrenToRemove = children.filter { child in
				guard child.name != nil else { return false }
				return child.name! == "Human"
			}
			
			//Remove them
			removeChildren(in: childrenToRemove)
			
			//Create new humans
			for (k, n) in population {
				createMany(humans: k, n)
			}
		}
	}
	
	//Initialize `GKScene` to store entities' `GKAgent2D`
	open let gkScene = GKScene()
	
	//`AgentComponent` GKComponentSystem.
	open let agentSystem: GKComponentSystem = GKComponentSystem(
		componentClass: AgentComponent.self)
	
	//`VisualComponent` GKComponentSystem.
	open let visualSystem: GKComponentSystem = GKComponentSystem(
		componentClass: VisualComponent.self)
	
	//`PhysicsComponent` GKComponentSystem.
	open let physicsSystem: GKComponentSystem = GKComponentSystem(
		componentClass: PhysicsComponent.self)
	
	//Random number source. Made it a linear congruential to keep it fast even if repeated every collision. A friend of mine chose the seed number 😅
	open let randomSource: GKLinearCongruentialRandomSource = GKLinearCongruentialRandomSource(seed: 7432389432)
	
	//When set, make it fill the scene and insert it below everything
	open var backgroundNode: SKSpriteNode? = nil {
		didSet {
			guard let b = backgroundNode else { return }
			
			b.fillTo(size: frame.size)
			b.position = frame.center
			
			self.insertChild(b, at: 0)
		}
	}
	
	//Proability of infection. 0 is 0%, 1 is 100%, 0.4 is 40%. Default value is 1.
	open var infectivity: Float? = nil

	public override required init(size: CGSize) {
		super.init(size: size)
	}
	
	//TODO: Write init(coder:)
	public required init?(coder aDecoder: NSCoder) {
		fatalError("init(coder:) has not been implemented")
	}

	override open func sceneDidLoad() {
		super.sceneDidLoad()
	
		//Set self as the `physicsWorld delegate`
		self.physicsWorld.contactDelegate = self
		
		//Turn gravity off
		self.physicsWorld.gravity = CGVector.zero
		
		//Give the scene a physical frame
		self.physicsBody = SKPhysicsBody(edgeLoopFrom: frame.insetBy(dx: World.physicFrameInset,
		                                                             dy: World.physicFrameInset))
		
		//Add the background Node
		if let back = backgroundNode {
			back.position = position
			back.size = frame.size
			self.addChild(back)
		}
	}
	
	//Utility function to create a human entity.
	open func createHuman(withKind k: Human.Kind) -> Human.Entity {
		let h = Human.Entity(inScene: self,
		                     ofKind: k)
		h.humanVisual.skNode.name = "Human"
		gkScene.addEntity(h)
		return h
	}
	
	//Utility function to create many human entities.
	open func createMany(humans k: Human.Kind, _ n: Int) {
		for _ in 0..<n {
			let _ = createHuman(withKind: k)
		}
	}
	
	//Utility function to create an item entity.
	open func createItem(withKind k: Item.Kind,
	                     inPosition pos: CGPoint) -> Item.Entity {
		let h = Item.Entity(inScene: self,
		                    ofKind: k,
		                    inPosition: pos)
		h.itemVisual.skNode.name = "Item"
		gkScene.addEntity(h)
		return h
	}
	
	//Utility function to create a random human entity.
	open func createRandomHuman() {
		let _ = createHuman(withKind: Human.Kind.random())
	}
	
	//Utility function to create a random item entity.
	open func createRandomItem() {
		let _ = createItem(withKind: Item.Kind.random(),
		                   inPosition: frame.randomPoint)
	}
	
	//Default states behaviors closures.
	open var normalStateClosure: (Human.Entity) -> (Human.Kind, SKAction?) = { _ in
		return (.Smile1, nil)
	}
	open var infectedStateClosure: (Human.Entity) -> (Human.Kind, SKAction?) = { _ in
		return (.Smile1, nil)
	}
	open var firstInfectedStateClosure: (Human.Entity) -> (Human.Kind, SKAction?) = { _ in
		return (.Smile1, nil)
	}
	open var immuneStateClosure: (Human.Entity) -> (Human.Kind, SKAction?) = { _ in
		return (.Smile1, nil)
	}
	
	//Default states behaviors functions.
	open func normalState(_ h: Human.Entity) -> (Human.Kind, SKAction?) {
		return normalStateClosure(h)
	}
	open func infectedState(_ h: Human.Entity) -> (Human.Kind, SKAction?) {
		return infectedStateClosure(h)
	}
	open func firstInfectedState(_ h: Human.Entity) -> (Human.Kind, SKAction?) {
		return firstInfectedStateClosure(h)
	}
	open func immuneState(_ h: Human.Entity) -> (Human.Kind, SKAction?) {
		return immuneStateClosure(h)
	}
	
	//MARK: - SKScene update
	
	///Keep the last update time to calculate delta time between frames.
	private var _lastUpdateTime: TimeInterval = 0
	
	///Update all the `GKComponentSystem` with the calculated delta time. 
	open override func update(_ currentTime: TimeInterval) {
		super.update(currentTime)
		
		if (_lastUpdateTime == 0) {
			_lastUpdateTime = currentTime;
		}
		
		let delta = currentTime - _lastUpdateTime;
		_lastUpdateTime = currentTime;
		
		agentSystem.update(deltaTime: delta)
		visualSystem.update(deltaTime: delta)
		physicsSystem.update(deltaTime: delta)
	}
	
	//MARK: - SKPhysicsContactDelegate
	open func didBegin(_ contact: SKPhysicsContact) {
		
		//Get entities
		guard let (humanA, humanB) = contactToEntities(contact) else { return }
		
		//Throw a dice (almost)
		let infectionChance = randomSource.nextUniform()
		
		//If he isn't immune nor lucky, infect him. If he was already infected, cure him and make him immune.
		if !humanB.isImmune && (humanA.isInfective && infectionChance < infectivity ?? 1) {
			humanB.isInfected = humanA.isInfected && !humanA.isImmune
			humanB.isInfective = true
			if !humanB.isInfected && allowImmunity {
				humanB.isInfected = false
				humanB.isImmune = true
			}
		}
		
		//Same for the other human in the contact.
		if !humanA.isImmune && (humanB.isInfective && infectionChance < infectivity ?? 1) {
			humanA.isInfected = humanB.isInfected && !humanB.isImmune
			humanA.isInfective = true
			if !humanA.isInfected && allowImmunity { humanA.isImmune = true }
		}
	}
	
	//Utility function to get entities from the `SKPhysicsContact`.
	open func contactToEntities(_ c: SKPhysicsContact) -> (a: Human.Entity, b: Human.Entity)? {
		guard
			let nodeA = c.bodyA.node,
			let nodeB = c.bodyB.node,
			let spriteA = nodeA as? HumanSpriteNode,
			let spriteB = nodeB as? HumanSpriteNode
			else { return nil }
		
		guard
			let visualA = spriteA.visualComponent,
			let visualB = spriteB.visualComponent
			else { return nil }
		
		guard
			let entityA = visualA.entity,
			let entityB = visualB.entity
			else { return nil }
		
		guard
			let humanA = entityA as? Human.Entity,
			let humanB = entityB as? Human.Entity
			else { return nil }
		
		return (a: humanA, b: humanB)
	}
}
