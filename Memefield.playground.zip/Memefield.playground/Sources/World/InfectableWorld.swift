import SpriteKit

//Protocol to define different states for humans in a infectable world.
public protocol InfectableWorld: SKPhysicsContactDelegate {
	
	func normalState(_ h: Human.Entity) -> (Human.Kind, SKAction?)
	func infectedState(_ h: Human.Entity) -> (Human.Kind, SKAction?)
	func firstInfectedState(_ h: Human.Entity) -> (Human.Kind, SKAction?)
	func immuneState(_ h: Human.Entity) -> (Human.Kind, SKAction?)
}
