import GameplayKit

///Component to add to `GKEntities` to manage behaviours. 
public class AgentComponent: GKAgent2D {
	
	//Values are taken directly from the struct `Humanity`, which provides various constants
	public override func didAddToEntity() {
		super.didAddToEntity()
	
		self.mass = Humanity.mass
		self.maxSpeed = Humanity.maxSpeed
		self.maxAcceleration = Humanity.maxAcceleration
	}
}

