import SpriteKit
import GameplayKit

///Component to add to `GKEntities` to manage the entity's `SKSpriteNode` subclass: `HumanSpriteNode`.
public class VisualComponent: GKComponent, HumanKindWatcher {
	
	public let skNode: HumanSpriteNode
	
	///Creates a new `Human.Entity` from its Kind's `rawValue`.
	init(withString kindString: String) {
		
		//isHuman is true if the string is any human kind rawValue and not an item kind rawValue
		let isHuman = !Human.Kind.allCases().filter { kindCase in
			return kindCase.rawValue == kindString
			}.isEmpty
		
		//Create and assign the sprite
		self.skNode = HumanSpriteNode(imageNamed: kindString)
		
		//MARK: The only interactable entities are humans.
		//TODO: Generalise this stuff in some way
		self.skNode.isUserInteractionEnabled = isHuman
		
		self.skNode.size = CGSize(width: Humanity.visualRadius,
		                          height: Humanity.visualRadius)
		
		super.init()
		
		self.skNode.visualComponent = self
	}
	
	///Init from Kind version. Applies the designed init with the `Kind.rawValue`.
	convenience public init(withKind kind: Human.Kind) {
		self.init(withString: kind.rawValue)
	}
	
	convenience public init(withKind kind: Item.Kind) {
		self.init(withString: kind.rawValue)
	}
	
	//Didn't bother to write this 😅
	//TODO: Write init(coder:)
	public required init?(coder aDecoder: NSCoder) {
		fatalError("init(coder:) has not been implemented")
	}
	
	// MARK: - HumanKindWatcher protocol
	
	// Keep `Human.Kind` and sprite in sync.
	public func update(kind: Human.Kind) {
		skNode.texture = kind.texture()
	}
	// Keep `Item.Kind` and sprite in sync.
	func update(kind: Item.Kind) {
		skNode.texture = kind.texture()
	}
}

