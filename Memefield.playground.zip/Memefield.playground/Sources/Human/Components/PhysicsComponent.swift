import SpriteKit
import GameplayKit

///Component to add to `GKEntities` to manage `SKSpriteNode`'s physicsBody.
public class PhysicsComponent: GKComponent {
	
	//Whenever this is update, it looks for the spriteNode physics body and assign itself to it.
	var body: SKPhysicsBody? = nil {
		didSet {
			guard
				let entity = entity,
				let spriteComponent = entity.component(ofType: VisualComponent.self)
				else { return }
			
			spriteComponent.skNode.physicsBody = self.body
		}
	}
	
	// MARK:  
	
	// TODO: Optimize the collision and contact masks (didn't have time 😅)
	public override func didAddToEntity() {
		super.didAddToEntity()
		
		self.body = SKPhysicsBody(circleOfRadius: Humanity.physicRadius)
		
		self.body?.categoryBitMask = 0x1 << 0
		
		self.body?.collisionBitMask = 0xFFFFFFFF
		
		self.body?.contactTestBitMask = 0xFFFFFFFF
	}
}
