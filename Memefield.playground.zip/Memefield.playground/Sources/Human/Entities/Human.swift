import GameplayKit

//TODO: Reformat `Human` and `Item` to share as much code as possible.

// Container class, just to have a nicer namespace.
public class Human {
	
	// Main human entity
	public class Entity: GKEntity {
		
		// Lots of stuff going on here. The next 4 Bools are the basic structure of this rudimental state machine.
		// TODO: Got to write this with `GKStateMachine`
		/// When set checks all the other parameters and apply the resulting state function.
		public var isInfected: Bool = false {
			didSet {
				
				// Check if the old value is different
				guard
					let scene = scene,
					isInfected != oldValue
					else { return }
				
				// Check if this human is immune to infections, if he is apply immune state
				guard !isImmune else {
					apply(stateFunc: scene.immuneState)
					return
				}
				
				// Check if this human is the first one the user clicked, if he is apply first state
				guard !isFirstInfected else {
					apply(stateFunc: scene.firstInfectedState)
					return
				}
				
				// Choose for the normal/infected state
				let state = isInfected ? scene.infectedState : scene.normalState
				
				// Apply result
				apply(stateFunc: state)
			}
		}
		
		/// Is true for the first human the user touch. Or it should be.
		// TODO: Got to write this with `GKStateMachine`. Really.
		public var isFirstInfected: Bool = false
		public var isInfective: Bool = false
		public var isImmune: Bool = false
		
		// Yeeeeh component bonanza! 🤓
		
		/// VisualComponent contains the human's `SKSpriteNode`
		public let humanVisual: VisualComponent
		
		/// VisualComponent contains the human's `SKPhysicsBody`
		public let humanPhysics: PhysicsComponent
		
		/// VisualComponent contains the human's `GKAgent2D`
		public let humanAgent: AgentComponent
		
		/// VisualComponent contains the human's `GKSKNodeComponent`. 
		/// It is needed to sychronize the positions of the spriteNode and the agent.
		public let humanGKSKNode: GKSKNodeComponent
		
		/// When set, call the update function for everyone who is observing this human Kind.
		/// Basically an event.
		public var kind: Kind {
			didSet {
				kindWatchers.forEach { $0.update(kind: kind) }
			}
		}

		/// List of objects to be notified of the change. They must conform to `HumanKindWatcher`
		public var kindWatchers: [HumanKindWatcher] = []
		
		/// Utility computed property to get the current world.
		public var scene: World? {
			guard
				let s = humanVisual.skNode.scene,
				let w = s as? World
				else { return nil }
			
			return w
		}
		
		/// Utility computed property to kickstart the default wander behavior.
		public static let wander: GKBehavior = {
			let goal = GKGoal(toWander: Humanity.wanderParameter)
			return GKBehavior.init(goal: goal, weight: Humanity.wanderWeight)
		}()
		
		/// This init puts directly a human inside the world.
		public init(inScene scene: World, ofKind k: Kind) {
			
			//Create components
			self.humanVisual = VisualComponent(withKind: k)
			self.humanPhysics = PhysicsComponent()
			self.humanGKSKNode = GKSKNodeComponent(node: humanVisual.skNode)
			self.humanAgent = AgentComponent()
			
			//Assign Kind
			self.kind = k
			
			super.init()
			
			//Now its a mess: 😅
			
			//Add `SKSpriteNode` to `SKScene`
			scene.addChild(humanVisual.skNode)
			
			//Set the `GKAgent2D delegate` to the `GKSKNodeComponent` to sync the sprite's and the agent's positions.
			humanAgent.delegate = humanGKSKNode
			
			//Add `GKSKNodeComponent` to self
			self.addComponent(humanGKSKNode)
			
			//Add `AgentComponent` to self
			self.addComponent(humanAgent)
			
			//Add `AgentComponent` to its component system in the `World`
			scene.agentSystem.addComponent(humanAgent)
			
			//Add `VisualComponent` to self
			self.addComponent(humanVisual)
			
			//Add `VisualComponent` to its component system in the `World`
			scene.visualSystem.addComponent(humanVisual)
			
			//Add `PhysicsComponent` to self
			self.addComponent(humanPhysics)
			
			//Add `PhysicsComponent` to its component system in the `World`
			scene.physicsSystem.addComponent(humanPhysics)
			
			//Add default wander behavior.
			self.humanAgent.behavior = Human.Entity.wander
			
			//Set `VisualComponent` to watch this human's `Kind`
			kindWatchers.append(humanVisual)
			
			//Update all watchers.
			kindWatchers.forEach { $0.update(kind: kind) }
			
			//Reposition randomly all humans.
			randomReposition()
		}
		
		//TODO: Write init(coder:)
		required public init?(coder aDecoder: NSCoder) {
			fatalError("init(coder:) has not been implemented")
		}
		
		//Utility function to apply a state function to this entity
		func apply(stateFunc: (Entity) -> (Human.Kind, SKAction?)) {
			
			//Get the results of the state function based on self.
			let state = stateFunc(self)
			
			//Assign the new kind to self.
			self.kind = state.0
			
			//Remove all actions from the `SKSpriteNode`.
			self.humanVisual.skNode.removeAllActions()
			
			//Assign the new action (if any) to self.
			if let action = state.1 {
				self.humanVisual.skNode.run(action)
			}
		}
		
		//Randomly reposition all the `SKSpriteNode` inside a frame defined by an inset value in `Humanity` (initialPositioningInsetPercentage).
		public func randomReposition() {
			
			guard let scene = scene else { return }
			
			let inset = (dx: scene.frame.size.width * Humanity.initialPositioningInsetPercentage.dx,
			             dy: scene.frame.size.height * Humanity.initialPositioningInsetPercentage.dy)
			
			self.humanVisual.skNode.position = scene.frame.insetBy(dx: inset.dx, dy: inset.dy).randomPoint
		}
	}
}

