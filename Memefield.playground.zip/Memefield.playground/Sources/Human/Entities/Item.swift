import GameplayKit

//TODO: Reformat `Human` and `Item` to share as much code as possible.

// Container class, just to have a nicer namespace.
public class Item {
	
	// Main item entity
	public class Entity: GKEntity {
		
		// Yeeeeh component bonanza! 🤓
		
		/// VisualComponent contains the human's `SKSpriteNode`
		public let itemVisual: VisualComponent
		
		/// VisualComponent contains the human's `SKPhysicsBody`
		public let itemPhysics: PhysicsComponent
		
		/// VisualComponent contains the human's `GKAgent2D`
		public let itemAgent: AgentComponent
		
		/// VisualComponent contains the human's `GKSKNodeComponent`.
		/// It is needed to sychronize the positions of the spriteNode and the agent.
		public let itemGKSK: GKSKNodeComponent
		
		/// When set, call the update function for everyone who is observing this human Kind.
		/// Basically an event.
		let kind: Kind
		
		/// Utility computed property to get the current world.
		weak var scene: World? {
			guard
				let s = itemVisual.skNode.scene,
				let w = s as? World
				else { return nil }
			
			return w
		}
		
		/// This init puts directly a item inside the world, spawning it in the selected CGPoint. It sets the size of items to the same size of humans.
		public init(inScene scene: World,
		            ofKind k: Kind,
		            inPosition pos: CGPoint) {
			
			//Create components
			self.itemVisual = VisualComponent(withKind: k)
			self.itemPhysics = PhysicsComponent()
			self.itemAgent = AgentComponent()
			self.itemGKSK = GKSKNodeComponent(node: itemVisual.skNode)
			
			//Assign Kind
			self.kind = k
			
			super.init()
			
			//Set the `GKAgent2D delegate` to the `GKSKNodeComponent` to sync the sprite's and the agent's positions.
			self.itemAgent.delegate = self.itemGKSK
			
			//Set the sprite node size to the default item radius.
			self.itemVisual.skNode.size = CGSize(width: Humanity.itemRadius * 2,
			                                           height: Humanity.itemRadius * 2)
			
			//Spawn the item in the specified position.
			self.itemVisual.skNode.position = pos
			
			//Set the `SKSpriteNode` entity to self
			self.itemVisual.skNode.entity = self
			
			//Add to self all the components.
			self.addComponent(itemVisual)
			self.addComponent(itemPhysics)
			self.addComponent(itemAgent)
			
			//Add the agent to its system in the `World`.
			scene.agentSystem.addComponent(itemAgent)
			
			//Add the `SKSpriteNode` to the `World`.
			scene.addChild(self.itemVisual.skNode)
		}
		
		//TODO: Check if I really need to do this deinit.
		//Remove all the entity components.
		deinit {
			self.removeComponent(ofType: VisualComponent.self)
			self.removeComponent(ofType: PhysicsComponent.self)
		}
		
		//TODO: Write init(coder:)
		required public init?(coder aDecoder: NSCoder) {
			fatalError("init(coder:) has not been implemented")
		}
		
	}
}
