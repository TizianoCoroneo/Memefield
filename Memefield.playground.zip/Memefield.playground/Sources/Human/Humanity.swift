import GameplayKit

// Utility struct to keep arbitrary constant values away from the logic code.
public struct Humanity {
	
	///Human `Kind`.
	public static var defaultKind: Human.Kind = .Smile1
	
	///Human `SKSpriteNode` radius.
	public static var visualRadius: CGFloat = 44
	
	///Human `SKPhysicsBody` radius.
	public static var physicRadius: CGFloat = visualRadius/2
	
	///Item default radius.
	public static var itemRadius: CGFloat = 22
	
	///Inset width and height / frame width and height.
	public static var initialPositioningInsetPercentage:
		(dx: CGFloat, dy: CGFloat) = (0.05, 0.05)
	
	///Entity mass. Given to GKAgent2D component.
	public static var mass: Float = 1
	
	///Entity max speed. Given to GKAgent2D component.
	public static var maxSpeed: Float = 30
	
	///Entity max acceleration. Given to GKAgent2D component.
	public static var maxAcceleration: Float = 3000
	
	
	//Default parameter for `GKGoal(toWander:)` function.
	public static var wanderParameter: Float = 100
	
	//Default parameter for `GKBehavior` init weight for default wander behavior.
	public static var wanderWeight: Float = 100
	
	//Default parameter for `GKBehavior` init weight for any behavior.
	public static var defaultBehaviourWeight: Float = 100
}
