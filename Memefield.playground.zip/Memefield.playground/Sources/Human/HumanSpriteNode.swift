import SpriteKit

///`SKSpriteNode` subclass made to respond to user input. Uses `touchesEnded` in iOS and `mouseUp` in macOS.
public class HumanSpriteNode : SKSpriteNode {
	
	public static var alreadyTouchedOne: Bool = false
	
	//Weak reference to the entity's VisualComponent.
	public weak var visualComponent: VisualComponent? = nil
	
	//Common function for touch behavior.
	func touch(human: Human.Entity) {

		//Skip if human is immune.
		guard !human.isImmune else { return }
		
		guard HumanSpriteNode.alreadyTouchedOne else {
			human.isInfected = true
			human.isInfective = true
			human.isFirstInfected = true
			HumanSpriteNode.alreadyTouchedOne = true
			return
		}
		
		//Toggle infected state.
		human.isInfected = !human.isInfected
		
		//Make the human infective.
		human.isInfective = true
		
		//If you're touching him to cure him, also make him immune.
		if !human.isInfected && (human.scene?.allowImmunity ?? true) {
			human.isImmune = true
		}
	}
	
	#if os(iOS)
	
	/// Gets iOS touch events.
	override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
		guard
			let visual = visualComponent,
			let e = visual.entity,
			let human = e as? Human.Entity
			else { return }
	
		touch(human: human)
	}
	
	#elseif os(OSX)
	
	/// Gets macOS touch events.
	override public func mouseUp(with event: NSEvent) {
		guard
			let visual = visualComponent,
			let e = visual.entity,
			let human = e as? Human.Entity
			else { return }
		
		touch(human: human)
	}
	
	#endif
}

